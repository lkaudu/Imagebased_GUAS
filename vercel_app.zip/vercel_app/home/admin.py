from django.contrib import admin
from .models import LoginInfo

admin.site.register(LoginInfo)
# admin.site.register(secondpassInfo)
# admin.site.register(thirdpassInfo)
# admin.site.register(Secondpass)
# admin.site.register(Thirdpass)